package com.group2.concord_messenger.ContactsActivityFolder

import android.graphics.Bitmap

data class ContactsData(val name: String, var isChecked: Boolean, val Image: Bitmap, val type: Int, var groupName: String){

}
